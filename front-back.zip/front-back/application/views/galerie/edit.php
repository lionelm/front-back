<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Galerie Edit</h3>
            </div>
			<?php echo form_open('galerie/edit/'.$galerie['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="categorie" class="control-label">Categorie</label>
						<div class="form-group">
							<input type="text" name="categorie" value="<?php echo ($this->input->post('categorie') ? $this->input->post('categorie') : $galerie['categorie']); ?>" class="form-control" id="categorie" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="sous_categorie" class="control-label">Sous Categorie</label>
						<div class="form-group">
							<input type="text" name="sous_categorie" value="<?php echo ($this->input->post('sous_categorie') ? $this->input->post('sous_categorie') : $galerie['sous_categorie']); ?>" class="form-control" id="sous_categorie" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="slug" class="control-label">Slug</label>
						<div class="form-group">
							<input type="text" name="slug" value="<?php echo ($this->input->post('slug') ? $this->input->post('slug') : $galerie['slug']); ?>" class="form-control" id="slug" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="valide" class="control-label">Valide</label>
						<div class="form-group">
							<input type="text" name="valide" value="<?php echo ($this->input->post('valide') ? $this->input->post('valide') : $galerie['valide']); ?>" class="form-control" id="valide" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="auteur" class="control-label">Auteur</label>
						<div class="form-group">
							<input type="text" name="auteur" value="<?php echo ($this->input->post('auteur') ? $this->input->post('auteur') : $galerie['auteur']); ?>" class="form-control" id="auteur" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="position" class="control-label">Position</label>
						<div class="form-group">
							<input type="text" name="position" value="<?php echo ($this->input->post('position') ? $this->input->post('position') : $galerie['position']); ?>" class="form-control" id="position" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="date" class="control-label">Date</label>
						<div class="form-group">
							<input type="text" name="date" value="<?php echo ($this->input->post('date') ? $this->input->post('date') : $galerie['date']); ?>" class="has-datepicker form-control" id="date" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="creer" class="control-label">Creer</label>
						<div class="form-group">
							<input type="text" name="creer" value="<?php echo ($this->input->post('creer') ? $this->input->post('creer') : $galerie['creer']); ?>" class="has-datepicker form-control" id="creer" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="modifier" class="control-label">Modifier</label>
						<div class="form-group">
							<input type="text" name="modifier" value="<?php echo ($this->input->post('modifier') ? $this->input->post('modifier') : $galerie['modifier']); ?>" class="has-datepicker form-control" id="modifier" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="contenu" class="control-label">Contenu</label>
						<div class="form-group">
							<textarea name="contenu" class="form-control" id="contenu"><?php echo ($this->input->post('contenu') ? $this->input->post('contenu') : $galerie['contenu']); ?></textarea>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>