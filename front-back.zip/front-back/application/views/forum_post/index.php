<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Forum Posts Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('forum_post/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>User Id</th>
						<th>Topic Id</th>
						<th>Created At</th>
						<th>Updated At</th>
						<th>Content</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($forum_posts as $f){ ?>
                    <tr>
						<td><?php echo $f['id']; ?></td>
						<td><?php echo $f['user_id']; ?></td>
						<td><?php echo $f['topic_id']; ?></td>
						<td><?php echo $f['created_at']; ?></td>
						<td><?php echo $f['updated_at']; ?></td>
						<td><?php echo $f['content']; ?></td>
						<td>
                            <a href="<?php echo site_url('forum_post/edit/'.$f['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('forum_post/remove/'.$f['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
