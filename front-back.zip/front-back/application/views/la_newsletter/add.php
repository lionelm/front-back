<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">La Newsletter Add</h3>
            </div>
            <?php echo form_open('la_newsletter/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="titre" class="control-label">Titre</label>
						<div class="form-group">
							<input type="text" name="titre" value="<?php echo $this->input->post('titre'); ?>" class="form-control" id="titre" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="groupe" class="control-label">Groupe</label>
						<div class="form-group">
							<input type="text" name="groupe" value="<?php echo $this->input->post('groupe'); ?>" class="form-control" id="groupe" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="valide" class="control-label">Valide</label>
						<div class="form-group">
							<input type="text" name="valide" value="<?php echo $this->input->post('valide'); ?>" class="form-control" id="valide" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="date" class="control-label">Date</label>
						<div class="form-group">
							<input type="text" name="date" value="<?php echo $this->input->post('date'); ?>" class="has-datepicker form-control" id="date" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="contenu" class="control-label">Contenu</label>
						<div class="form-group">
							<textarea name="contenu" class="form-control" id="contenu"><?php echo $this->input->post('contenu'); ?></textarea>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>