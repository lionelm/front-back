<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Visit Add</h3>
            </div>
            <?php echo form_open('visit/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<div class="form-group">
							<input type="checkbox" name="visit_is_direct_access" value="1"  id="visit_is_direct_access" />
							<label for="visit_is_direct_access" class="control-label">Visit Is Direct Access</label>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<input type="checkbox" name="visit_is_external_referral" value="1"  id="visit_is_external_referral" />
							<label for="visit_is_external_referral" class="control-label">Visit Is External Referral</label>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<input type="checkbox" name="visit_is_search_referral" value="1"  id="visit_is_search_referral" />
							<label for="visit_is_search_referral" class="control-label">Visit Is Search Referral</label>
						</div>
					</div>
					<div class="col-md-6">
						<label for="visit_entry_visit_id" class="control-label">Visit Entry Visit Id</label>
						<div class="form-group">
							<input type="text" name="visit_entry_visit_id" value="<?php echo $this->input->post('visit_entry_visit_id'); ?>" class="form-control" id="visit_entry_visit_id" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="visit_visitor_id" class="control-label">Visit Visitor Id</label>
						<div class="form-group">
							<input type="text" name="visit_visitor_id" value="<?php echo $this->input->post('visit_visitor_id'); ?>" class="form-control" id="visit_visitor_id" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="visit_visit_date" class="control-label">Visit Visit Date</label>
						<div class="form-group">
							<input type="text" name="visit_visit_date" value="<?php echo $this->input->post('visit_visit_date'); ?>" class="has-datetimepicker form-control" id="visit_visit_date" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="visit_referrer" class="control-label">Visit Referrer</label>
						<div class="form-group">
							<input type="text" name="visit_referrer" value="<?php echo $this->input->post('visit_referrer'); ?>" class="form-control" id="visit_referrer" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="visit_uri" class="control-label">Visit Uri</label>
						<div class="form-group">
							<input type="text" name="visit_uri" value="<?php echo $this->input->post('visit_uri'); ?>" class="form-control" id="visit_uri" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>