<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Visit Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('visit/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>Visit Id</th>
						<th>Visit Is Direct Access</th>
						<th>Visit Is External Referral</th>
						<th>Visit Is Search Referral</th>
						<th>Visit Entry Visit Id</th>
						<th>Visit Visitor Id</th>
						<th>Visit Visit Date</th>
						<th>Visit Referrer</th>
						<th>Visit Uri</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($visit as $v){ ?>
                    <tr>
						<td><?php echo $v['visit_id']; ?></td>
						<td><?php echo $v['visit_is_direct_access']; ?></td>
						<td><?php echo $v['visit_is_external_referral']; ?></td>
						<td><?php echo $v['visit_is_search_referral']; ?></td>
						<td><?php echo $v['visit_entry_visit_id']; ?></td>
						<td><?php echo $v['visit_visitor_id']; ?></td>
						<td><?php echo $v['visit_visit_date']; ?></td>
						<td><?php echo $v['visit_referrer']; ?></td>
						<td><?php echo $v['visit_uri']; ?></td>
						<td>
                            <a href="<?php echo site_url('visit/edit/'.$v['visit_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('visit/remove/'.$v['visit_id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
