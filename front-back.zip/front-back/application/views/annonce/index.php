<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Annonce Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('annonce/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>Titre</th>
						<th>Slug</th>
						<th>Date</th>
						<th>Categorie</th>
						<th>Images</th>
						<th>Email</th>
						<th>Tel</th>
						<th>Nom Prenom</th>
						<th>Adresse</th>
						<th>Cp Ville</th>
						<th>Valide</th>
						<th>Share</th>
						<th>Modifier</th>
						<th>Contenu</th>
						<th>Tags</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($annonce as $a){ ?>
                    <tr>
						<td><?php echo $a['id']; ?></td>
						<td><?php echo $a['titre']; ?></td>
						<td><?php echo $a['slug']; ?></td>
						<td><?php echo $a['date']; ?></td>
						<td><?php echo $a['categorie']; ?></td>
						<td><?php echo $a['images']; ?></td>
						<td><?php echo $a['email']; ?></td>
						<td><?php echo $a['tel']; ?></td>
						<td><?php echo $a['nom_prenom']; ?></td>
						<td><?php echo $a['adresse']; ?></td>
						<td><?php echo $a['cp_ville']; ?></td>
						<td><?php echo $a['valide']; ?></td>
						<td><?php echo $a['share']; ?></td>
						<td><?php echo $a['modifier']; ?></td>
						<td><?php echo $a['contenu']; ?></td>
						<td><?php echo $a['tags']; ?></td>
						<td>
                            <a href="<?php echo site_url('annonce/edit/'.$a['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('annonce/remove/'.$a['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
