<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Forums Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('forum/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>Title</th>
						<th>Slug</th>
						<th>Description</th>
						<th>Created At</th>
						<th>Updated At</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($forums as $f){ ?>
                    <tr>
						<td><?php echo $f['id']; ?></td>
						<td><?php echo $f['title']; ?></td>
						<td><?php echo $f['slug']; ?></td>
						<td><?php echo $f['description']; ?></td>
						<td><?php echo $f['created_at']; ?></td>
						<td><?php echo $f['updated_at']; ?></td>
						<td>
                            <a href="<?php echo site_url('forum/edit/'.$f['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('forum/remove/'.$f['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
