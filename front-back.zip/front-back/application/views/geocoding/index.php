<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Geocoding Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('geocoding/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>Titre</th>
						<th>Adresse</th>
						<th>Region</th>
						<th>Email</th>
						<th>Latitude</th>
						<th>Longitude</th>
						<th>Valide</th>
						<th>Date</th>
						<th>Creer</th>
						<th>Modifier</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($geocoding as $g){ ?>
                    <tr>
						<td><?php echo $g['id']; ?></td>
						<td><?php echo $g['titre']; ?></td>
						<td><?php echo $g['adresse']; ?></td>
						<td><?php echo $g['region']; ?></td>
						<td><?php echo $g['email']; ?></td>
						<td><?php echo $g['latitude']; ?></td>
						<td><?php echo $g['longitude']; ?></td>
						<td><?php echo $g['valide']; ?></td>
						<td><?php echo $g['date']; ?></td>
						<td><?php echo $g['creer']; ?></td>
						<td><?php echo $g['modifier']; ?></td>
						<td>
                            <a href="<?php echo site_url('geocoding/edit/'.$g['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('geocoding/remove/'.$g['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
