<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Label Add</h3>
            </div>
            <?php echo form_open('label/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="user_id" class="control-label">User Id</label>
						<div class="form-group">
							<input type="text" name="user_id" value="<?php echo $this->input->post('user_id'); ?>" class="form-control" id="user_id" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="groups" class="control-label">Groups</label>
						<div class="form-group">
							<input type="text" name="groups" value="<?php echo $this->input->post('groups'); ?>" class="form-control" id="groups" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="label" class="control-label">Label</label>
						<div class="form-group">
							<input type="text" name="label" value="<?php echo $this->input->post('label'); ?>" class="form-control" id="label" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="color" class="control-label">Color</label>
						<div class="form-group">
							<input type="text" name="color" value="<?php echo $this->input->post('color'); ?>" class="form-control" id="color" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="system" class="control-label">System</label>
						<div class="form-group">
							<input type="text" name="system" value="<?php echo $this->input->post('system'); ?>" class="form-control" id="system" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>