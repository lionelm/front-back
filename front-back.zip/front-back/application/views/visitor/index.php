<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Visitor Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('visitor/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>Visitor Id</th>
						<th>Visitor Is Mobile</th>
						<th>Visitor Is Browser</th>
						<th>Visitor Is Robot</th>
						<th>Visitor Agent</th>
						<th>Visitor Platform</th>
						<th>Visitor User Agent String</th>
						<th>Visitor Ip Address</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($visitor as $v){ ?>
                    <tr>
						<td><?php echo $v['visitor_id']; ?></td>
						<td><?php echo $v['visitor_is_mobile']; ?></td>
						<td><?php echo $v['visitor_is_browser']; ?></td>
						<td><?php echo $v['visitor_is_robot']; ?></td>
						<td><?php echo $v['visitor_agent']; ?></td>
						<td><?php echo $v['visitor_platform']; ?></td>
						<td><?php echo $v['visitor_user_agent_string']; ?></td>
						<td><?php echo $v['visitor_ip_address']; ?></td>
						<td>
                            <a href="<?php echo site_url('visitor/edit/'.$v['visitor_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('visitor/remove/'.$v['visitor_id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
