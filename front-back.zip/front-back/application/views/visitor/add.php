<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Visitor Add</h3>
            </div>
            <?php echo form_open('visitor/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<div class="form-group">
							<input type="checkbox" name="visitor_is_mobile" value="1"  id="visitor_is_mobile" />
							<label for="visitor_is_mobile" class="control-label">Visitor Is Mobile</label>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<input type="checkbox" name="visitor_is_browser" value="1"  id="visitor_is_browser" />
							<label for="visitor_is_browser" class="control-label">Visitor Is Browser</label>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<input type="checkbox" name="visitor_is_robot" value="1"  id="visitor_is_robot" />
							<label for="visitor_is_robot" class="control-label">Visitor Is Robot</label>
						</div>
					</div>
					<div class="col-md-6">
						<label for="visitor_agent" class="control-label">Visitor Agent</label>
						<div class="form-group">
							<input type="text" name="visitor_agent" value="<?php echo $this->input->post('visitor_agent'); ?>" class="form-control" id="visitor_agent" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="visitor_platform" class="control-label">Visitor Platform</label>
						<div class="form-group">
							<input type="text" name="visitor_platform" value="<?php echo $this->input->post('visitor_platform'); ?>" class="form-control" id="visitor_platform" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="visitor_user_agent_string" class="control-label">Visitor User Agent String</label>
						<div class="form-group">
							<input type="text" name="visitor_user_agent_string" value="<?php echo $this->input->post('visitor_user_agent_string'); ?>" class="form-control" id="visitor_user_agent_string" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="visitor_ip_address" class="control-label">Visitor Ip Address</label>
						<div class="form-group">
							<input type="text" name="visitor_ip_address" value="<?php echo $this->input->post('visitor_ip_address'); ?>" class="form-control" id="visitor_ip_address" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>