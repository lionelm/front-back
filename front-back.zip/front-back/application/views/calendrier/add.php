<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Calendrier Add</h3>
            </div>
            <?php echo form_open('calendrier/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="categorie" class="control-label">Categorie</label>
						<div class="form-group">
							<input type="text" name="categorie" value="<?php echo $this->input->post('categorie'); ?>" class="form-control" id="categorie" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="titre" class="control-label">Titre</label>
						<div class="form-group">
							<input type="text" name="titre" value="<?php echo $this->input->post('titre'); ?>" class="form-control" id="titre" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="slug" class="control-label">Slug</label>
						<div class="form-group">
							<input type="text" name="slug" value="<?php echo $this->input->post('slug'); ?>" class="form-control" id="slug" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="auteur" class="control-label">Auteur</label>
						<div class="form-group">
							<input type="text" name="auteur" value="<?php echo $this->input->post('auteur'); ?>" class="form-control" id="auteur" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="valide" class="control-label">Valide</label>
						<div class="form-group">
							<input type="text" name="valide" value="<?php echo $this->input->post('valide'); ?>" class="form-control" id="valide" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="nom" class="control-label">Nom</label>
						<div class="form-group">
							<input type="text" name="nom" value="<?php echo $this->input->post('nom'); ?>" class="form-control" id="nom" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="address" class="control-label">Address</label>
						<div class="form-group">
							<input type="text" name="address" value="<?php echo $this->input->post('address'); ?>" class="form-control" id="address" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="lieu" class="control-label">Lieu</label>
						<div class="form-group">
							<input type="text" name="lieu" value="<?php echo $this->input->post('lieu'); ?>" class="form-control" id="lieu" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="email" class="control-label">Email</label>
						<div class="form-group">
							<input type="text" name="email" value="<?php echo $this->input->post('email'); ?>" class="form-control" id="email" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="tel" class="control-label">Tel</label>
						<div class="form-group">
							<input type="text" name="tel" value="<?php echo $this->input->post('tel'); ?>" class="form-control" id="tel" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="fax" class="control-label">Fax</label>
						<div class="form-group">
							<input type="text" name="fax" value="<?php echo $this->input->post('fax'); ?>" class="form-control" id="fax" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="latitude" class="control-label">Latitude</label>
						<div class="form-group">
							<input type="text" name="latitude" value="<?php echo $this->input->post('latitude'); ?>" class="form-control" id="latitude" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="longitude" class="control-label">Longitude</label>
						<div class="form-group">
							<input type="text" name="longitude" value="<?php echo $this->input->post('longitude'); ?>" class="form-control" id="longitude" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="date" class="control-label">Date</label>
						<div class="form-group">
							<input type="text" name="date" value="<?php echo $this->input->post('date'); ?>" class="has-datepicker form-control" id="date" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="date_debut" class="control-label">Date Debut</label>
						<div class="form-group">
							<input type="text" name="date_debut" value="<?php echo $this->input->post('date_debut'); ?>" class="has-datepicker form-control" id="date_debut" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="date_fin" class="control-label">Date Fin</label>
						<div class="form-group">
							<input type="text" name="date_fin" value="<?php echo $this->input->post('date_fin'); ?>" class="has-datepicker form-control" id="date_fin" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="debut_periode" class="control-label">Debut Periode</label>
						<div class="form-group">
							<input type="text" name="debut_periode" value="<?php echo $this->input->post('debut_periode'); ?>" class="form-control" id="debut_periode" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="fin_periode" class="control-label">Fin Periode</label>
						<div class="form-group">
							<input type="text" name="fin_periode" value="<?php echo $this->input->post('fin_periode'); ?>" class="form-control" id="fin_periode" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="share" class="control-label">Share</label>
						<div class="form-group">
							<input type="text" name="share" value="<?php echo $this->input->post('share'); ?>" class="form-control" id="share" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="creer" class="control-label">Creer</label>
						<div class="form-group">
							<input type="text" name="creer" value="<?php echo $this->input->post('creer'); ?>" class="has-datetimepicker form-control" id="creer" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="modifier" class="control-label">Modifier</label>
						<div class="form-group">
							<input type="text" name="modifier" value="<?php echo $this->input->post('modifier'); ?>" class="has-datetimepicker form-control" id="modifier" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="contenu" class="control-label">Contenu</label>
						<div class="form-group">
							<textarea name="contenu" class="form-control" id="contenu"><?php echo $this->input->post('contenu'); ?></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label for="tags" class="control-label">Tags</label>
						<div class="form-group">
							<textarea name="tags" class="form-control" id="tags"><?php echo $this->input->post('tags'); ?></textarea>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>