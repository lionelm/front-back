<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Pages Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('page/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>Titre</th>
						<th>Slug</th>
						<th>Ordre</th>
						<th>Parent Id</th>
						<th>Categorie</th>
						<th>Intro</th>
						<th>Valide</th>
						<th>In Menu</th>
						<th>Partage</th>
						<th>Contenu</th>
						<th>Tags</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($pages as $p){ ?>
                    <tr>
						<td><?php echo $p['id']; ?></td>
						<td><?php echo $p['titre']; ?></td>
						<td><?php echo $p['slug']; ?></td>
						<td><?php echo $p['ordre']; ?></td>
						<td><?php echo $p['parent_id']; ?></td>
						<td><?php echo $p['categorie']; ?></td>
						<td><?php echo $p['intro']; ?></td>
						<td><?php echo $p['valide']; ?></td>
						<td><?php echo $p['in_menu']; ?></td>
						<td><?php echo $p['partage']; ?></td>
						<td><?php echo $p['contenu']; ?></td>
						<td><?php echo $p['tags']; ?></td>
						<td>
                            <a href="<?php echo site_url('page/edit/'.$p['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('page/remove/'.$p['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
