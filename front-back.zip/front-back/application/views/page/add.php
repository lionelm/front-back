<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Page Add</h3>
            </div>
            <?php echo form_open('page/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="titre" class="control-label">Titre</label>
						<div class="form-group">
							<input type="text" name="titre" value="<?php echo $this->input->post('titre'); ?>" class="form-control" id="titre" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="slug" class="control-label">Slug</label>
						<div class="form-group">
							<input type="text" name="slug" value="<?php echo $this->input->post('slug'); ?>" class="form-control" id="slug" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ordre" class="control-label">Ordre</label>
						<div class="form-group">
							<input type="text" name="ordre" value="<?php echo $this->input->post('ordre'); ?>" class="form-control" id="ordre" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="parent_id" class="control-label">Parent Id</label>
						<div class="form-group">
							<input type="text" name="parent_id" value="<?php echo $this->input->post('parent_id'); ?>" class="form-control" id="parent_id" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="categorie" class="control-label">Categorie</label>
						<div class="form-group">
							<input type="text" name="categorie" value="<?php echo $this->input->post('categorie'); ?>" class="form-control" id="categorie" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="intro" class="control-label">Intro</label>
						<div class="form-group">
							<input type="text" name="intro" value="<?php echo $this->input->post('intro'); ?>" class="form-control" id="intro" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="valide" class="control-label">Valide</label>
						<div class="form-group">
							<input type="text" name="valide" value="<?php echo $this->input->post('valide'); ?>" class="form-control" id="valide" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="in_menu" class="control-label">In Menu</label>
						<div class="form-group">
							<input type="text" name="in_menu" value="<?php echo $this->input->post('in_menu'); ?>" class="form-control" id="in_menu" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="partage" class="control-label">Partage</label>
						<div class="form-group">
							<input type="text" name="partage" value="<?php echo $this->input->post('partage'); ?>" class="form-control" id="partage" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="contenu" class="control-label">Contenu</label>
						<div class="form-group">
							<textarea name="contenu" class="form-control" id="contenu"><?php echo $this->input->post('contenu'); ?></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label for="tags" class="control-label">Tags</label>
						<div class="form-group">
							<textarea name="tags" class="form-control" id="tags"><?php echo $this->input->post('tags'); ?></textarea>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>