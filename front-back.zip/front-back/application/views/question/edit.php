<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Question Edit</h3>
            </div>
			<?php echo form_open('question/edit/'.$question['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="question" class="control-label">Question</label>
						<div class="form-group">
							<input type="text" name="question" value="<?php echo ($this->input->post('question') ? $this->input->post('question') : $question['question']); ?>" class="form-control" id="question" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="up_vote" class="control-label">Up Vote</label>
						<div class="form-group">
							<input type="text" name="up_vote" value="<?php echo ($this->input->post('up_vote') ? $this->input->post('up_vote') : $question['up_vote']); ?>" class="form-control" id="up_vote" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="down_vote" class="control-label">Down Vote</label>
						<div class="form-group">
							<input type="text" name="down_vote" value="<?php echo ($this->input->post('down_vote') ? $this->input->post('down_vote') : $question['down_vote']); ?>" class="form-control" id="down_vote" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="valider" class="control-label">Valider</label>
						<div class="form-group">
							<input type="text" name="valider" value="<?php echo ($this->input->post('valider') ? $this->input->post('valider') : $question['valider']); ?>" class="form-control" id="valider" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="publier" class="control-label">Publier</label>
						<div class="form-group">
							<input type="text" name="publier" value="<?php echo ($this->input->post('publier') ? $this->input->post('publier') : $question['publier']); ?>" class="has-datepicker form-control" id="publier" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="modifier" class="control-label">Modifier</label>
						<div class="form-group">
							<input type="text" name="modifier" value="<?php echo ($this->input->post('modifier') ? $this->input->post('modifier') : $question['modifier']); ?>" class="has-datepicker form-control" id="modifier" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>