<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Abecedaire Add</h3>
            </div>
            <?php echo form_open('abecedaire/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="categorie" class="control-label"><span class="text-danger">*</span>Categorie</label>
						<div class="form-group">
							<select name="categorie" class="form-control">
								<option value="">select</option>
								<?php 
								$categorie_values = array(
								);

								foreach($categorie_values as $value => $display_text)
								{
									$selected = ($value == $this->input->post('categorie')) ? ' selected="selected"' : "";

									echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('categorie');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="valide" class="control-label"><span class="text-danger">*</span>Valide</label>
						<div class="form-group">
							<select name="valide" class="form-control">
								<option value="">select</option>
								<?php 
								$valide_values = array(
									'1'=>'oui',
									'0'=>'non',
								);

								foreach($valide_values as $value => $display_text)
								{
									$selected = ($value == $this->input->post('valide')) ? ' selected="selected"' : "";

									echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('valide');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="style" class="control-label"><span class="text-danger">*</span>Style</label>
						<div class="form-group">
							<select name="style" class="form-control">
								<option value="">select</option>
								<?php 
								$style_values = array(
								);

								foreach($style_values as $value => $display_text)
								{
									$selected = ($value == $this->input->post('style')) ? ' selected="selected"' : "";

									echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('style');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="titre" class="control-label"><span class="text-danger">*</span>Titre</label>
						<div class="form-group">
							<input type="text" name="titre" value="<?php echo $this->input->post('titre'); ?>" class="form-control" id="titre" />
							<span class="text-danger"><?php echo form_error('titre');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="tags" class="control-label"><span class="text-danger">*</span>Tags</label>
						<div class="form-group">
							<input type="text" name="tags" value="<?php echo $this->input->post('tags'); ?>" class="form-control" id="tags" />
							<span class="text-danger"><?php echo form_error('tags');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="date" class="control-label"><span class="text-danger">*</span>Date</label>
						<div class="form-group">
							<input type="text" name="date" value="<?php echo $this->input->post('date'); ?>" class="has-datepicker form-control" id="date" />
							<span class="text-danger"><?php echo form_error('date');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="creer" class="control-label"><span class="text-danger">*</span>Creer</label>
						<div class="form-group">
							<input type="text" name="creer" value="<?php echo $this->input->post('creer'); ?>" class="has-datetimepicker form-control" id="creer" />
							<span class="text-danger"><?php echo form_error('creer');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="modifier" class="control-label"><span class="text-danger">*</span>Modifier</label>
						<div class="form-group">
							<input type="text" name="modifier" value="<?php echo $this->input->post('modifier'); ?>" class="has-datetimepicker form-control" id="modifier" />
							<span class="text-danger"><?php echo form_error('modifier');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="contenu" class="control-label"><span class="text-danger">*</span>Contenu</label>
						<div class="form-group">
							<textarea name="contenu" class="form-control" id="contenu"><?php echo $this->input->post('contenu'); ?></textarea>
							<span class="text-danger"><?php echo form_error('contenu');?></span>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>