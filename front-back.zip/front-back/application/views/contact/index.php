<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Contact Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('contact/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>Reponse</th>
						<th>Date</th>
						<th>Creer</th>
						<th>Modifier</th>
						<th>Valide</th>
						<th>Nom</th>
						<th>Prenom</th>
						<th>Sujet</th>
						<th>Email</th>
						<th>Contenu</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($contact as $c){ ?>
                    <tr>
						<td><?php echo $c['id']; ?></td>
						<td><?php echo $c['reponse']; ?></td>
						<td><?php echo $c['date']; ?></td>
						<td><?php echo $c['creer']; ?></td>
						<td><?php echo $c['modifier']; ?></td>
						<td><?php echo $c['valide']; ?></td>
						<td><?php echo $c['nom']; ?></td>
						<td><?php echo $c['prenom']; ?></td>
						<td><?php echo $c['sujet']; ?></td>
						<td><?php echo $c['email']; ?></td>
						<td><?php echo $c['contenu']; ?></td>
						<td>
                            <a href="<?php echo site_url('contact/edit/'.$c['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('contact/remove/'.$c['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
