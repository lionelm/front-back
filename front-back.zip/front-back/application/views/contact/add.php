<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Contact Add</h3>
            </div>
            <?php echo form_open('contact/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="reponse" class="control-label">Reponse</label>
						<div class="form-group">
							<input type="text" name="reponse" value="<?php echo $this->input->post('reponse'); ?>" class="has-datepicker form-control" id="reponse" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="date" class="control-label">Date</label>
						<div class="form-group">
							<input type="text" name="date" value="<?php echo $this->input->post('date'); ?>" class="form-control" id="date" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="creer" class="control-label">Creer</label>
						<div class="form-group">
							<input type="text" name="creer" value="<?php echo $this->input->post('creer'); ?>" class="has-datetimepicker form-control" id="creer" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="modifier" class="control-label">Modifier</label>
						<div class="form-group">
							<input type="text" name="modifier" value="<?php echo $this->input->post('modifier'); ?>" class="has-datetimepicker form-control" id="modifier" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="valide" class="control-label">Valide</label>
						<div class="form-group">
							<input type="text" name="valide" value="<?php echo $this->input->post('valide'); ?>" class="form-control" id="valide" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="nom" class="control-label">Nom</label>
						<div class="form-group">
							<input type="text" name="nom" value="<?php echo $this->input->post('nom'); ?>" class="form-control" id="nom" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="prenom" class="control-label">Prenom</label>
						<div class="form-group">
							<input type="text" name="prenom" value="<?php echo $this->input->post('prenom'); ?>" class="form-control" id="prenom" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="sujet" class="control-label">Sujet</label>
						<div class="form-group">
							<input type="text" name="sujet" value="<?php echo $this->input->post('sujet'); ?>" class="form-control" id="sujet" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="email" class="control-label">Email</label>
						<div class="form-group">
							<textarea name="email" class="form-control" id="email"><?php echo $this->input->post('email'); ?></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label for="contenu" class="control-label">Contenu</label>
						<div class="form-group">
							<textarea name="contenu" class="form-control" id="contenu"><?php echo $this->input->post('contenu'); ?></textarea>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>