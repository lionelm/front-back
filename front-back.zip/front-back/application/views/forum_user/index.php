<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Forum Users Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('forum_user/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>Password</th>
						<th>Username</th>
						<th>Email</th>
						<th>Avatar</th>
						<th>Created At</th>
						<th>Updated At</th>
						<th>Updated By</th>
						<th>Is Admin</th>
						<th>Is Moderator</th>
						<th>Is Confirmed</th>
						<th>Is Deleted</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($forum_users as $f){ ?>
                    <tr>
						<td><?php echo $f['id']; ?></td>
						<td><?php echo $f['password']; ?></td>
						<td><?php echo $f['username']; ?></td>
						<td><?php echo $f['email']; ?></td>
						<td><?php echo $f['avatar']; ?></td>
						<td><?php echo $f['created_at']; ?></td>
						<td><?php echo $f['updated_at']; ?></td>
						<td><?php echo $f['updated_by']; ?></td>
						<td><?php echo $f['is_admin']; ?></td>
						<td><?php echo $f['is_moderator']; ?></td>
						<td><?php echo $f['is_confirmed']; ?></td>
						<td><?php echo $f['is_deleted']; ?></td>
						<td>
                            <a href="<?php echo site_url('forum_user/edit/'.$f['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('forum_user/remove/'.$f['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
