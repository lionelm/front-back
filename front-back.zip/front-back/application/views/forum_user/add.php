<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Forum User Add</h3>
            </div>
            <?php echo form_open('forum_user/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="password" class="control-label">Password</label>
						<div class="form-group">
							<input type="password" name="password" value="<?php echo $this->input->post('password'); ?>" class="form-control" id="password" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="username" class="control-label">Username</label>
						<div class="form-group">
							<input type="text" name="username" value="<?php echo $this->input->post('username'); ?>" class="form-control" id="username" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="email" class="control-label">Email</label>
						<div class="form-group">
							<input type="text" name="email" value="<?php echo $this->input->post('email'); ?>" class="form-control" id="email" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="avatar" class="control-label">Avatar</label>
						<div class="form-group">
							<input type="text" name="avatar" value="<?php echo $this->input->post('avatar'); ?>" class="form-control" id="avatar" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="created_at" class="control-label">Created At</label>
						<div class="form-group">
							<input type="text" name="created_at" value="<?php echo $this->input->post('created_at'); ?>" class="has-datetimepicker form-control" id="created_at" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="updated_at" class="control-label">Updated At</label>
						<div class="form-group">
							<input type="text" name="updated_at" value="<?php echo $this->input->post('updated_at'); ?>" class="has-datetimepicker form-control" id="updated_at" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="updated_by" class="control-label">Updated By</label>
						<div class="form-group">
							<input type="text" name="updated_by" value="<?php echo $this->input->post('updated_by'); ?>" class="form-control" id="updated_by" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="is_admin" class="control-label">Is Admin</label>
						<div class="form-group">
							<input type="text" name="is_admin" value="<?php echo $this->input->post('is_admin'); ?>" class="form-control" id="is_admin" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="is_moderator" class="control-label">Is Moderator</label>
						<div class="form-group">
							<input type="text" name="is_moderator" value="<?php echo $this->input->post('is_moderator'); ?>" class="form-control" id="is_moderator" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="is_confirmed" class="control-label">Is Confirmed</label>
						<div class="form-group">
							<input type="text" name="is_confirmed" value="<?php echo $this->input->post('is_confirmed'); ?>" class="form-control" id="is_confirmed" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="is_deleted" class="control-label">Is Deleted</label>
						<div class="form-group">
							<input type="text" name="is_deleted" value="<?php echo $this->input->post('is_deleted'); ?>" class="form-control" id="is_deleted" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>