<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Forum User Edit</h3>
            </div>
			<?php echo form_open('forum_user/edit/'.$forum_user['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="password" class="control-label">Password</label>
						<div class="form-group">
							<input type="text" name="password" value="<?php echo ($this->input->post('password') ? $this->input->post('password') : $forum_user['password']); ?>" class="form-control" id="password" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="username" class="control-label">Username</label>
						<div class="form-group">
							<input type="text" name="username" value="<?php echo ($this->input->post('username') ? $this->input->post('username') : $forum_user['username']); ?>" class="form-control" id="username" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="email" class="control-label">Email</label>
						<div class="form-group">
							<input type="text" name="email" value="<?php echo ($this->input->post('email') ? $this->input->post('email') : $forum_user['email']); ?>" class="form-control" id="email" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="avatar" class="control-label">Avatar</label>
						<div class="form-group">
							<input type="text" name="avatar" value="<?php echo ($this->input->post('avatar') ? $this->input->post('avatar') : $forum_user['avatar']); ?>" class="form-control" id="avatar" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="created_at" class="control-label">Created At</label>
						<div class="form-group">
							<input type="text" name="created_at" value="<?php echo ($this->input->post('created_at') ? $this->input->post('created_at') : $forum_user['created_at']); ?>" class="has-datetimepicker form-control" id="created_at" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="updated_at" class="control-label">Updated At</label>
						<div class="form-group">
							<input type="text" name="updated_at" value="<?php echo ($this->input->post('updated_at') ? $this->input->post('updated_at') : $forum_user['updated_at']); ?>" class="has-datetimepicker form-control" id="updated_at" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="updated_by" class="control-label">Updated By</label>
						<div class="form-group">
							<input type="text" name="updated_by" value="<?php echo ($this->input->post('updated_by') ? $this->input->post('updated_by') : $forum_user['updated_by']); ?>" class="form-control" id="updated_by" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="is_admin" class="control-label">Is Admin</label>
						<div class="form-group">
							<input type="text" name="is_admin" value="<?php echo ($this->input->post('is_admin') ? $this->input->post('is_admin') : $forum_user['is_admin']); ?>" class="form-control" id="is_admin" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="is_moderator" class="control-label">Is Moderator</label>
						<div class="form-group">
							<input type="text" name="is_moderator" value="<?php echo ($this->input->post('is_moderator') ? $this->input->post('is_moderator') : $forum_user['is_moderator']); ?>" class="form-control" id="is_moderator" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="is_confirmed" class="control-label">Is Confirmed</label>
						<div class="form-group">
							<input type="text" name="is_confirmed" value="<?php echo ($this->input->post('is_confirmed') ? $this->input->post('is_confirmed') : $forum_user['is_confirmed']); ?>" class="form-control" id="is_confirmed" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="is_deleted" class="control-label">Is Deleted</label>
						<div class="form-group">
							<input type="text" name="is_deleted" value="<?php echo ($this->input->post('is_deleted') ? $this->input->post('is_deleted') : $forum_user['is_deleted']); ?>" class="form-control" id="is_deleted" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>