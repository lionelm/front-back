<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Signature Edit</h3>
            </div>
			<?php echo form_open('signature/edit/'.$signature['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="date" class="control-label">Date</label>
						<div class="form-group">
							<input type="text" name="date" value="<?php echo ($this->input->post('date') ? $this->input->post('date') : $signature['date']); ?>" class="has-datepicker form-control" id="date" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="nom" class="control-label">Nom</label>
						<div class="form-group">
							<input type="text" name="nom" value="<?php echo ($this->input->post('nom') ? $this->input->post('nom') : $signature['nom']); ?>" class="form-control" id="nom" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="valide" class="control-label">Valide</label>
						<div class="form-group">
							<input type="text" name="valide" value="<?php echo ($this->input->post('valide') ? $this->input->post('valide') : $signature['valide']); ?>" class="form-control" id="valide" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="courriel" class="control-label">Courriel</label>
						<div class="form-group">
							<textarea name="courriel" class="form-control" id="courriel"><?php echo ($this->input->post('courriel') ? $this->input->post('courriel') : $signature['courriel']); ?></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label for="contenu" class="control-label">Contenu</label>
						<div class="form-group">
							<textarea name="contenu" class="form-control" id="contenu"><?php echo ($this->input->post('contenu') ? $this->input->post('contenu') : $signature['contenu']); ?></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label for="domaine" class="control-label">Domaine</label>
						<div class="form-group">
							<textarea name="domaine" class="form-control" id="domaine"><?php echo ($this->input->post('domaine') ? $this->input->post('domaine') : $signature['domaine']); ?></textarea>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>