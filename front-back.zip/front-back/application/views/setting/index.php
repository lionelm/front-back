<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Settings Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('setting/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>G Password</th>
						<th>Nom Site</th>
						<th>Email Site</th>
						<th>Copyright</th>
						<th>Auteur</th>
						<th>Site En Cache</th>
						<th>Site Admin</th>
						<th>Par Page Intro</th>
						<th>Par Page</th>
						<th>Maintenance</th>
						<th>Protocol</th>
						<th>Smtpsecure</th>
						<th>Smtphost</th>
						<th>Smtpport</th>
						<th>Smtpuser</th>
						<th>Smtppass</th>
						<th>Mailtype</th>
						<th>G Profile Id</th>
						<th>G Email</th>
						<th>Ga Tracking</th>
						<th>Valide</th>
						<th>Publier</th>
						<th>Modifier</th>
						<th>Mots Clefs</th>
						<th>Description Site</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($settings as $s){ ?>
                    <tr>
						<td><?php echo $s['id']; ?></td>
						<td><?php echo $s['g_password']; ?></td>
						<td><?php echo $s['nom_site']; ?></td>
						<td><?php echo $s['email_site']; ?></td>
						<td><?php echo $s['copyright']; ?></td>
						<td><?php echo $s['auteur']; ?></td>
						<td><?php echo $s['site_en_cache']; ?></td>
						<td><?php echo $s['site_admin']; ?></td>
						<td><?php echo $s['par_page_intro']; ?></td>
						<td><?php echo $s['par_page']; ?></td>
						<td><?php echo $s['maintenance']; ?></td>
						<td><?php echo $s['protocol']; ?></td>
						<td><?php echo $s['smtpsecure']; ?></td>
						<td><?php echo $s['smtphost']; ?></td>
						<td><?php echo $s['smtpport']; ?></td>
						<td><?php echo $s['smtpuser']; ?></td>
						<td><?php echo $s['smtppass']; ?></td>
						<td><?php echo $s['mailtype']; ?></td>
						<td><?php echo $s['g_profile_id']; ?></td>
						<td><?php echo $s['g_email']; ?></td>
						<td><?php echo $s['ga_tracking']; ?></td>
						<td><?php echo $s['valide']; ?></td>
						<td><?php echo $s['publier']; ?></td>
						<td><?php echo $s['modifier']; ?></td>
						<td><?php echo $s['mots_clefs']; ?></td>
						<td><?php echo $s['description_site']; ?></td>
						<td>
                            <a href="<?php echo site_url('setting/edit/'.$s['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('setting/remove/'.$s['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
