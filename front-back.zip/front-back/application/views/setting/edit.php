<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Setting Edit</h3>
            </div>
			<?php echo form_open('setting/edit/'.$setting['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="g_password" class="control-label">G Password</label>
						<div class="form-group">
							<input type="text" name="g_password" value="<?php echo ($this->input->post('g_password') ? $this->input->post('g_password') : $setting['g_password']); ?>" class="form-control" id="g_password" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="nom_site" class="control-label">Nom Site</label>
						<div class="form-group">
							<input type="text" name="nom_site" value="<?php echo ($this->input->post('nom_site') ? $this->input->post('nom_site') : $setting['nom_site']); ?>" class="form-control" id="nom_site" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="email_site" class="control-label">Email Site</label>
						<div class="form-group">
							<input type="text" name="email_site" value="<?php echo ($this->input->post('email_site') ? $this->input->post('email_site') : $setting['email_site']); ?>" class="form-control" id="email_site" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="copyright" class="control-label">Copyright</label>
						<div class="form-group">
							<input type="text" name="copyright" value="<?php echo ($this->input->post('copyright') ? $this->input->post('copyright') : $setting['copyright']); ?>" class="form-control" id="copyright" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="auteur" class="control-label">Auteur</label>
						<div class="form-group">
							<input type="text" name="auteur" value="<?php echo ($this->input->post('auteur') ? $this->input->post('auteur') : $setting['auteur']); ?>" class="form-control" id="auteur" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="site_en_cache" class="control-label">Site En Cache</label>
						<div class="form-group">
							<input type="text" name="site_en_cache" value="<?php echo ($this->input->post('site_en_cache') ? $this->input->post('site_en_cache') : $setting['site_en_cache']); ?>" class="form-control" id="site_en_cache" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="site_admin" class="control-label">Site Admin</label>
						<div class="form-group">
							<input type="text" name="site_admin" value="<?php echo ($this->input->post('site_admin') ? $this->input->post('site_admin') : $setting['site_admin']); ?>" class="form-control" id="site_admin" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="par_page_intro" class="control-label">Par Page Intro</label>
						<div class="form-group">
							<input type="text" name="par_page_intro" value="<?php echo ($this->input->post('par_page_intro') ? $this->input->post('par_page_intro') : $setting['par_page_intro']); ?>" class="form-control" id="par_page_intro" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="par_page" class="control-label">Par Page</label>
						<div class="form-group">
							<input type="text" name="par_page" value="<?php echo ($this->input->post('par_page') ? $this->input->post('par_page') : $setting['par_page']); ?>" class="form-control" id="par_page" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="maintenance" class="control-label">Maintenance</label>
						<div class="form-group">
							<input type="text" name="maintenance" value="<?php echo ($this->input->post('maintenance') ? $this->input->post('maintenance') : $setting['maintenance']); ?>" class="form-control" id="maintenance" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="protocol" class="control-label">Protocol</label>
						<div class="form-group">
							<input type="text" name="protocol" value="<?php echo ($this->input->post('protocol') ? $this->input->post('protocol') : $setting['protocol']); ?>" class="form-control" id="protocol" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="smtpsecure" class="control-label">Smtpsecure</label>
						<div class="form-group">
							<input type="text" name="smtpsecure" value="<?php echo ($this->input->post('smtpsecure') ? $this->input->post('smtpsecure') : $setting['smtpsecure']); ?>" class="form-control" id="smtpsecure" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="smtphost" class="control-label">Smtphost</label>
						<div class="form-group">
							<input type="text" name="smtphost" value="<?php echo ($this->input->post('smtphost') ? $this->input->post('smtphost') : $setting['smtphost']); ?>" class="form-control" id="smtphost" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="smtpport" class="control-label">Smtpport</label>
						<div class="form-group">
							<input type="text" name="smtpport" value="<?php echo ($this->input->post('smtpport') ? $this->input->post('smtpport') : $setting['smtpport']); ?>" class="form-control" id="smtpport" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="smtpuser" class="control-label">Smtpuser</label>
						<div class="form-group">
							<input type="text" name="smtpuser" value="<?php echo ($this->input->post('smtpuser') ? $this->input->post('smtpuser') : $setting['smtpuser']); ?>" class="form-control" id="smtpuser" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="smtppass" class="control-label">Smtppass</label>
						<div class="form-group">
							<input type="text" name="smtppass" value="<?php echo ($this->input->post('smtppass') ? $this->input->post('smtppass') : $setting['smtppass']); ?>" class="form-control" id="smtppass" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="mailtype" class="control-label">Mailtype</label>
						<div class="form-group">
							<input type="text" name="mailtype" value="<?php echo ($this->input->post('mailtype') ? $this->input->post('mailtype') : $setting['mailtype']); ?>" class="form-control" id="mailtype" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="g_profile_id" class="control-label">G Profile Id</label>
						<div class="form-group">
							<input type="text" name="g_profile_id" value="<?php echo ($this->input->post('g_profile_id') ? $this->input->post('g_profile_id') : $setting['g_profile_id']); ?>" class="form-control" id="g_profile_id" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="g_email" class="control-label">G Email</label>
						<div class="form-group">
							<input type="text" name="g_email" value="<?php echo ($this->input->post('g_email') ? $this->input->post('g_email') : $setting['g_email']); ?>" class="form-control" id="g_email" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="ga_tracking" class="control-label">Ga Tracking</label>
						<div class="form-group">
							<input type="text" name="ga_tracking" value="<?php echo ($this->input->post('ga_tracking') ? $this->input->post('ga_tracking') : $setting['ga_tracking']); ?>" class="form-control" id="ga_tracking" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="valide" class="control-label">Valide</label>
						<div class="form-group">
							<input type="text" name="valide" value="<?php echo ($this->input->post('valide') ? $this->input->post('valide') : $setting['valide']); ?>" class="form-control" id="valide" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="publier" class="control-label">Publier</label>
						<div class="form-group">
							<input type="text" name="publier" value="<?php echo ($this->input->post('publier') ? $this->input->post('publier') : $setting['publier']); ?>" class="has-datepicker form-control" id="publier" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="modifier" class="control-label">Modifier</label>
						<div class="form-group">
							<input type="text" name="modifier" value="<?php echo ($this->input->post('modifier') ? $this->input->post('modifier') : $setting['modifier']); ?>" class="has-datepicker form-control" id="modifier" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="mots_clefs" class="control-label">Mots Clefs</label>
						<div class="form-group">
							<textarea name="mots_clefs" class="form-control" id="mots_clefs"><?php echo ($this->input->post('mots_clefs') ? $this->input->post('mots_clefs') : $setting['mots_clefs']); ?></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label for="description_site" class="control-label">Description Site</label>
						<div class="form-group">
							<textarea name="description_site" class="form-control" id="description_site"><?php echo ($this->input->post('description_site') ? $this->input->post('description_site') : $setting['description_site']); ?></textarea>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>