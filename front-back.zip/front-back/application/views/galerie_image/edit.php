<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Galerie Image Edit</h3>
            </div>
			<?php echo form_open('galerie_image/edit/'.$galerie_image['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="id_galerie" class="control-label">Id Galerie</label>
						<div class="form-group">
							<input type="text" name="id_galerie" value="<?php echo ($this->input->post('id_galerie') ? $this->input->post('id_galerie') : $galerie_image['id_galerie']); ?>" class="form-control" id="id_galerie" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="categorie" class="control-label">Categorie</label>
						<div class="form-group">
							<input type="text" name="categorie" value="<?php echo ($this->input->post('categorie') ? $this->input->post('categorie') : $galerie_image['categorie']); ?>" class="form-control" id="categorie" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="image" class="control-label">Image</label>
						<div class="form-group">
							<input type="text" name="image" value="<?php echo ($this->input->post('image') ? $this->input->post('image') : $galerie_image['image']); ?>" class="form-control" id="image" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="valide" class="control-label">Valide</label>
						<div class="form-group">
							<input type="text" name="valide" value="<?php echo ($this->input->post('valide') ? $this->input->post('valide') : $galerie_image['valide']); ?>" class="form-control" id="valide" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="date" class="control-label">Date</label>
						<div class="form-group">
							<input type="text" name="date" value="<?php echo ($this->input->post('date') ? $this->input->post('date') : $galerie_image['date']); ?>" class="has-datepicker form-control" id="date" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="creer" class="control-label">Creer</label>
						<div class="form-group">
							<input type="text" name="creer" value="<?php echo ($this->input->post('creer') ? $this->input->post('creer') : $galerie_image['creer']); ?>" class="has-datepicker form-control" id="creer" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="modifier" class="control-label">Modifier</label>
						<div class="form-group">
							<input type="text" name="modifier" value="<?php echo ($this->input->post('modifier') ? $this->input->post('modifier') : $galerie_image['modifier']); ?>" class="has-datepicker form-control" id="modifier" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="contenu" class="control-label">Contenu</label>
						<div class="form-group">
							<textarea name="contenu" class="form-control" id="contenu"><?php echo ($this->input->post('contenu') ? $this->input->post('contenu') : $galerie_image['contenu']); ?></textarea>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>