<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Comment Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('comment/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>Auteur</th>
						<th>Email</th>
						<th>Date</th>
						<th>Id Article</th>
						<th>Slug</th>
						<th>Valide</th>
						<th>Modifier</th>
						<th>Contenu</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($comment as $c){ ?>
                    <tr>
						<td><?php echo $c['id']; ?></td>
						<td><?php echo $c['auteur']; ?></td>
						<td><?php echo $c['email']; ?></td>
						<td><?php echo $c['date']; ?></td>
						<td><?php echo $c['id_article']; ?></td>
						<td><?php echo $c['slug']; ?></td>
						<td><?php echo $c['valide']; ?></td>
						<td><?php echo $c['modifier']; ?></td>
						<td><?php echo $c['contenu']; ?></td>
						<td>
                            <a href="<?php echo site_url('comment/edit/'.$c['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('comment/remove/'.$c['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
