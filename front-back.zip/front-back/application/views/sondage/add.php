<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Sondage Add</h3>
            </div>
            <?php echo form_open('sondage/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="question" class="control-label">Question</label>
						<div class="form-group">
							<input type="text" name="question" value="<?php echo $this->input->post('question'); ?>" class="form-control" id="question" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="question_1" class="control-label">Question 1</label>
						<div class="form-group">
							<input type="text" name="question_1" value="<?php echo $this->input->post('question_1'); ?>" class="form-control" id="question_1" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="question_2" class="control-label">Question 2</label>
						<div class="form-group">
							<input type="text" name="question_2" value="<?php echo $this->input->post('question_2'); ?>" class="form-control" id="question_2" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="question_3" class="control-label">Question 3</label>
						<div class="form-group">
							<input type="text" name="question_3" value="<?php echo $this->input->post('question_3'); ?>" class="form-control" id="question_3" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="question_4" class="control-label">Question 4</label>
						<div class="form-group">
							<input type="text" name="question_4" value="<?php echo $this->input->post('question_4'); ?>" class="form-control" id="question_4" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="question_5" class="control-label">Question 5</label>
						<div class="form-group">
							<input type="text" name="question_5" value="<?php echo $this->input->post('question_5'); ?>" class="form-control" id="question_5" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="reponse_1" class="control-label">Reponse 1</label>
						<div class="form-group">
							<input type="text" name="reponse_1" value="<?php echo $this->input->post('reponse_1'); ?>" class="form-control" id="reponse_1" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="reponse_2" class="control-label">Reponse 2</label>
						<div class="form-group">
							<input type="text" name="reponse_2" value="<?php echo $this->input->post('reponse_2'); ?>" class="form-control" id="reponse_2" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="reponse_3" class="control-label">Reponse 3</label>
						<div class="form-group">
							<input type="text" name="reponse_3" value="<?php echo $this->input->post('reponse_3'); ?>" class="form-control" id="reponse_3" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="reponse_4" class="control-label">Reponse 4</label>
						<div class="form-group">
							<input type="text" name="reponse_4" value="<?php echo $this->input->post('reponse_4'); ?>" class="form-control" id="reponse_4" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="reponse_5" class="control-label">Reponse 5</label>
						<div class="form-group">
							<input type="text" name="reponse_5" value="<?php echo $this->input->post('reponse_5'); ?>" class="form-control" id="reponse_5" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="fermer" class="control-label">Fermer</label>
						<div class="form-group">
							<input type="text" name="fermer" value="<?php echo $this->input->post('fermer'); ?>" class="form-control" id="fermer" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="publier" class="control-label">Publier</label>
						<div class="form-group">
							<input type="text" name="publier" value="<?php echo $this->input->post('publier'); ?>" class="has-datepicker form-control" id="publier" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="valider" class="control-label">Valider</label>
						<div class="form-group">
							<input type="text" name="valider" value="<?php echo $this->input->post('valider'); ?>" class="form-control" id="valider" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="modifier" class="control-label">Modifier</label>
						<div class="form-group">
							<input type="text" name="modifier" value="<?php echo $this->input->post('modifier'); ?>" class="has-datepicker form-control" id="modifier" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>