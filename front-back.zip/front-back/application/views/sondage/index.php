<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Sondage Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('sondage/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>Question</th>
						<th>Question 1</th>
						<th>Question 2</th>
						<th>Question 3</th>
						<th>Question 4</th>
						<th>Question 5</th>
						<th>Reponse 1</th>
						<th>Reponse 2</th>
						<th>Reponse 3</th>
						<th>Reponse 4</th>
						<th>Reponse 5</th>
						<th>Fermer</th>
						<th>Publier</th>
						<th>Valider</th>
						<th>Modifier</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($sondage as $s){ ?>
                    <tr>
						<td><?php echo $s['id']; ?></td>
						<td><?php echo $s['question']; ?></td>
						<td><?php echo $s['question_1']; ?></td>
						<td><?php echo $s['question_2']; ?></td>
						<td><?php echo $s['question_3']; ?></td>
						<td><?php echo $s['question_4']; ?></td>
						<td><?php echo $s['question_5']; ?></td>
						<td><?php echo $s['reponse_1']; ?></td>
						<td><?php echo $s['reponse_2']; ?></td>
						<td><?php echo $s['reponse_3']; ?></td>
						<td><?php echo $s['reponse_4']; ?></td>
						<td><?php echo $s['reponse_5']; ?></td>
						<td><?php echo $s['fermer']; ?></td>
						<td><?php echo $s['publier']; ?></td>
						<td><?php echo $s['valider']; ?></td>
						<td><?php echo $s['modifier']; ?></td>
						<td>
                            <a href="<?php echo site_url('sondage/edit/'.$s['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('sondage/remove/'.$s['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
