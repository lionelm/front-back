<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Ecrit Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('ecrit/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>Titre</th>
						<th>Publier</th>
						<th>Valide</th>
						<th>Share</th>
						<th>In Intro</th>
						<th>Modifier</th>
						<th>Contenu</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($ecrit as $e){ ?>
                    <tr>
						<td><?php echo $e['id']; ?></td>
						<td><?php echo $e['titre']; ?></td>
						<td><?php echo $e['publier']; ?></td>
						<td><?php echo $e['valide']; ?></td>
						<td><?php echo $e['share']; ?></td>
						<td><?php echo $e['in_intro']; ?></td>
						<td><?php echo $e['modifier']; ?></td>
						<td><?php echo $e['contenu']; ?></td>
						<td>
                            <a href="<?php echo site_url('ecrit/edit/'.$e['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('ecrit/remove/'.$e['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
