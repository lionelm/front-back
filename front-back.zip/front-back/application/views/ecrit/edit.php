<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Ecrit Edit</h3>
            </div>
			<?php echo form_open('ecrit/edit/'.$ecrit['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="titre" class="control-label">Titre</label>
						<div class="form-group">
							<input type="text" name="titre" value="<?php echo ($this->input->post('titre') ? $this->input->post('titre') : $ecrit['titre']); ?>" class="form-control" id="titre" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="publier" class="control-label">Publier</label>
						<div class="form-group">
							<input type="text" name="publier" value="<?php echo ($this->input->post('publier') ? $this->input->post('publier') : $ecrit['publier']); ?>" class="has-datepicker form-control" id="publier" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="valide" class="control-label">Valide</label>
						<div class="form-group">
							<input type="text" name="valide" value="<?php echo ($this->input->post('valide') ? $this->input->post('valide') : $ecrit['valide']); ?>" class="form-control" id="valide" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="share" class="control-label">Share</label>
						<div class="form-group">
							<input type="text" name="share" value="<?php echo ($this->input->post('share') ? $this->input->post('share') : $ecrit['share']); ?>" class="form-control" id="share" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="in_intro" class="control-label">In Intro</label>
						<div class="form-group">
							<input type="text" name="in_intro" value="<?php echo ($this->input->post('in_intro') ? $this->input->post('in_intro') : $ecrit['in_intro']); ?>" class="form-control" id="in_intro" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="modifier" class="control-label">Modifier</label>
						<div class="form-group">
							<input type="text" name="modifier" value="<?php echo ($this->input->post('modifier') ? $this->input->post('modifier') : $ecrit['modifier']); ?>" class="has-datepicker form-control" id="modifier" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="contenu" class="control-label">Contenu</label>
						<div class="form-group">
							<textarea name="contenu" class="form-control" id="contenu"><?php echo ($this->input->post('contenu') ? $this->input->post('contenu') : $ecrit['contenu']); ?></textarea>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>