<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Message Edit</h3>
            </div>
			<?php echo form_open('message/edit/'.$message['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<div class="form-group">
							<input type="checkbox" name="is_read" value="1" <?php echo ($message['is_read']==1 ? 'checked="checked"' : ''); ?> id='is_read' />
							<label for="is_read" class="control-label">Is Read</label>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<input type="checkbox" name="is_star" value="1" <?php echo ($message['is_star']==1 ? 'checked="checked"' : ''); ?> id='is_star' />
							<label for="is_star" class="control-label">Is Star</label>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<input type="checkbox" name="have_attachment" value="1" <?php echo ($message['have_attachment']==1 ? 'checked="checked"' : ''); ?> id='have_attachment' />
							<label for="have_attachment" class="control-label">Have Attachment</label>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<input type="checkbox" name="trash" value="1" <?php echo ($message['trash']==1 ? 'checked="checked"' : ''); ?> id='trash' />
							<label for="trash" class="control-label">Trash</label>
						</div>
					</div>
					<div class="col-md-6">
						<label for="parent_id" class="control-label">Parent Id</label>
						<div class="form-group">
							<input type="text" name="parent_id" value="<?php echo ($this->input->post('parent_id') ? $this->input->post('parent_id') : $message['parent_id']); ?>" class="form-control" id="parent_id" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="type" class="control-label">Type</label>
						<div class="form-group">
							<input type="text" name="type" value="<?php echo ($this->input->post('type') ? $this->input->post('type') : $message['type']); ?>" class="form-control" id="type" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="receiver" class="control-label">Receiver</label>
						<div class="form-group">
							<input type="text" name="receiver" value="<?php echo ($this->input->post('receiver') ? $this->input->post('receiver') : $message['receiver']); ?>" class="form-control" id="receiver" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="author" class="control-label">Author</label>
						<div class="form-group">
							<input type="text" name="author" value="<?php echo ($this->input->post('author') ? $this->input->post('author') : $message['author']); ?>" class="form-control" id="author" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="label" class="control-label">Label</label>
						<div class="form-group">
							<input type="text" name="label" value="<?php echo ($this->input->post('label') ? $this->input->post('label') : $message['label']); ?>" class="form-control" id="label" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="subject" class="control-label">Subject</label>
						<div class="form-group">
							<input type="text" name="subject" value="<?php echo ($this->input->post('subject') ? $this->input->post('subject') : $message['subject']); ?>" class="form-control" id="subject" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="created" class="control-label">Created</label>
						<div class="form-group">
							<input type="text" name="created" value="<?php echo ($this->input->post('created') ? $this->input->post('created') : $message['created']); ?>" class="form-control" id="created" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="body" class="control-label">Body</label>
						<div class="form-group">
							<textarea name="body" class="form-control" id="body"><?php echo ($this->input->post('body') ? $this->input->post('body') : $message['body']); ?></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label for="attachments" class="control-label">Attachments</label>
						<div class="form-group">
							<textarea name="attachments" class="form-control" id="attachments"><?php echo ($this->input->post('attachments') ? $this->input->post('attachments') : $message['attachments']); ?></textarea>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>