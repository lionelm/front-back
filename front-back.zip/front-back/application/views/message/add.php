<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Message Add</h3>
            </div>
            <?php echo form_open('message/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<div class="form-group">
							<input type="checkbox" name="is_read" value="1"  id="is_read" />
							<label for="is_read" class="control-label">Is Read</label>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<input type="checkbox" name="is_star" value="1"  id="is_star" />
							<label for="is_star" class="control-label">Is Star</label>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<input type="checkbox" name="have_attachment" value="1"  id="have_attachment" />
							<label for="have_attachment" class="control-label">Have Attachment</label>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<input type="checkbox" name="trash" value="1"  id="trash" />
							<label for="trash" class="control-label">Trash</label>
						</div>
					</div>
					<div class="col-md-6">
						<label for="parent_id" class="control-label">Parent Id</label>
						<div class="form-group">
							<input type="text" name="parent_id" value="<?php echo $this->input->post('parent_id'); ?>" class="form-control" id="parent_id" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="type" class="control-label">Type</label>
						<div class="form-group">
							<input type="text" name="type" value="<?php echo $this->input->post('type'); ?>" class="form-control" id="type" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="receiver" class="control-label">Receiver</label>
						<div class="form-group">
							<input type="text" name="receiver" value="<?php echo $this->input->post('receiver'); ?>" class="form-control" id="receiver" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="author" class="control-label">Author</label>
						<div class="form-group">
							<input type="text" name="author" value="<?php echo $this->input->post('author'); ?>" class="form-control" id="author" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="label" class="control-label">Label</label>
						<div class="form-group">
							<input type="text" name="label" value="<?php echo $this->input->post('label'); ?>" class="form-control" id="label" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="subject" class="control-label">Subject</label>
						<div class="form-group">
							<input type="text" name="subject" value="<?php echo $this->input->post('subject'); ?>" class="form-control" id="subject" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="created" class="control-label">Created</label>
						<div class="form-group">
							<input type="text" name="created" value="<?php echo $this->input->post('created'); ?>" class="form-control" id="created" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="body" class="control-label">Body</label>
						<div class="form-group">
							<textarea name="body" class="form-control" id="body"><?php echo $this->input->post('body'); ?></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label for="attachments" class="control-label">Attachments</label>
						<div class="form-group">
							<textarea name="attachments" class="form-control" id="attachments"><?php echo $this->input->post('attachments'); ?></textarea>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>